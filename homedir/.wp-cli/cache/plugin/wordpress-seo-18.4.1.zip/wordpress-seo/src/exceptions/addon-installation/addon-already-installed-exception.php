<?php

// phpcs:disable Yoast.NamingConventions.ObjectNameDepth.MaxExceeded -- Discussed in Tech Council, a better solution is being worked on.

namespace Yoast\WP\SEO\Exceptions\Addon_Installation;

use Exception;

/**
 * Class Addon_Already_Installed_Exception
 */
class Addon_Already_Installed_Exception extends Exception {}
