/**
 * Javascript.
 *
 * @package CreativeMail
 */

import ConsentCheckoutCapture from './ConsentCheckoutCapture';

// Capture consent
const MyConsentCheckoutCapture = new ConsentCheckoutCapture();
MyConsentCheckoutCapture.init();
